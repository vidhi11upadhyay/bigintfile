# BIGINT
#this code is all about performing arithematic functions that is addition,subtraction,multiplication and division on big integers that are basically above long int in c language. 
#In this we are using linked list and that too singly this because we can create links between numbers at different memory location and can store big integers.
